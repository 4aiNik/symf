<?php

/* @App/Posts/posts.html.twig */
class __TwigTemplate_c4ec494540366e64db07a4b85abc07d2a0e44df223aca8c7cde510a9f070fb51 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@App/index.html.twig", "@App/Posts/posts.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@App/index.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1a6d53c093f458a0b951940c1a1bef593639f03335643851131f9392ff8270b5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1a6d53c093f458a0b951940c1a1bef593639f03335643851131f9392ff8270b5->enter($__internal_1a6d53c093f458a0b951940c1a1bef593639f03335643851131f9392ff8270b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/Posts/posts.html.twig"));

        $__internal_11f08d457b8e66b58b676c57e26de774f243d86d35b882537b91fb6d4967ca96 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_11f08d457b8e66b58b676c57e26de774f243d86d35b882537b91fb6d4967ca96->enter($__internal_11f08d457b8e66b58b676c57e26de774f243d86d35b882537b91fb6d4967ca96_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/Posts/posts.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1a6d53c093f458a0b951940c1a1bef593639f03335643851131f9392ff8270b5->leave($__internal_1a6d53c093f458a0b951940c1a1bef593639f03335643851131f9392ff8270b5_prof);

        
        $__internal_11f08d457b8e66b58b676c57e26de774f243d86d35b882537b91fb6d4967ca96->leave($__internal_11f08d457b8e66b58b676c57e26de774f243d86d35b882537b91fb6d4967ca96_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_597f84c2b537a31d18aec369627186303f885615de073a460ab2d4a92cd53bee = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_597f84c2b537a31d18aec369627186303f885615de073a460ab2d4a92cd53bee->enter($__internal_597f84c2b537a31d18aec369627186303f885615de073a460ab2d4a92cd53bee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_d45080f652dfbee26c4abdced41b34e98367d92f6f7555db1703fadd0e8fb50a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d45080f652dfbee26c4abdced41b34e98367d92f6f7555db1703fadd0e8fb50a->enter($__internal_d45080f652dfbee26c4abdced41b34e98367d92f6f7555db1703fadd0e8fb50a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Посты";
        
        $__internal_d45080f652dfbee26c4abdced41b34e98367d92f6f7555db1703fadd0e8fb50a->leave($__internal_d45080f652dfbee26c4abdced41b34e98367d92f6f7555db1703fadd0e8fb50a_prof);

        
        $__internal_597f84c2b537a31d18aec369627186303f885615de073a460ab2d4a92cd53bee->leave($__internal_597f84c2b537a31d18aec369627186303f885615de073a460ab2d4a92cd53bee_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_06c68c58736b1da552dea8fb6f8c72207aabcc7f2e9295bab56907e2de042d97 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_06c68c58736b1da552dea8fb6f8c72207aabcc7f2e9295bab56907e2de042d97->enter($__internal_06c68c58736b1da552dea8fb6f8c72207aabcc7f2e9295bab56907e2de042d97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_03f0ac33d8fa2c5d458a482e02d8a5dda1841cca7c15c00539c4708a06f2096d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_03f0ac33d8fa2c5d458a482e02d8a5dda1841cca7c15c00539c4708a06f2096d->enter($__internal_03f0ac33d8fa2c5d458a482e02d8a5dda1841cca7c15c00539c4708a06f2096d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "    <div class=\"container\">
        <div class=\"row\">
            <form class=\"navbar-form navbar-right\" role=\"search\">
                <div class=\"form-group\">
                    <input type=\"text\" name=\"search\" class=\"form-control\" placeholder=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "search"), "method"), "html", null, true);
        echo "\">
                </div>
                <button type=\"submit\" class=\"btn btn-default\">Поиск</button>
            </form>
        </div>

        ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["posts"] ?? $this->getContext($context, "posts")));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 16
            echo "            <div class=\"jumbotron\">
                <h1>";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "username", array()), "html", null, true);
            echo "</h1>
                <p class=\"content\">";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
            echo "</p>
                <p class=\"content\">";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "content", array()), "html", null, true);
            echo "</p>
                <p class=\"created_at\">";
            // line 20
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["post"], "createdAt", array()), "d.m.Y H:i:s"), "html", null, true);
            echo "</p>
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "    </div>
";
        
        $__internal_03f0ac33d8fa2c5d458a482e02d8a5dda1841cca7c15c00539c4708a06f2096d->leave($__internal_03f0ac33d8fa2c5d458a482e02d8a5dda1841cca7c15c00539c4708a06f2096d_prof);

        
        $__internal_06c68c58736b1da552dea8fb6f8c72207aabcc7f2e9295bab56907e2de042d97->leave($__internal_06c68c58736b1da552dea8fb6f8c72207aabcc7f2e9295bab56907e2de042d97_prof);

    }

    public function getTemplateName()
    {
        return "@App/Posts/posts.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  111 => 23,  102 => 20,  98 => 19,  94 => 18,  90 => 17,  87 => 16,  83 => 15,  74 => 9,  68 => 5,  59 => 4,  41 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@App/index.html.twig' %}
{% block title %}Посты{% endblock %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <form class=\"navbar-form navbar-right\" role=\"search\">
                <div class=\"form-group\">
                    <input type=\"text\" name=\"search\" class=\"form-control\" placeholder=\"{{ app.request.get('search') }}\">
                </div>
                <button type=\"submit\" class=\"btn btn-default\">Поиск</button>
            </form>
        </div>

        {% for post in posts %}
            <div class=\"jumbotron\">
                <h1>{{ post.username }}</h1>
                <p class=\"content\">{{ post.title }}</p>
                <p class=\"content\">{{ post.content }}</p>
                <p class=\"created_at\">{{ post.createdAt|date('d.m.Y H:i:s') }}</p>
            </div>
        {% endfor %}
    </div>
{% endblock %}
", "@App/Posts/posts.html.twig", "/var/www/html/symfony/src/AppBundle/Resources/views/Posts/posts.html.twig");
    }
}
