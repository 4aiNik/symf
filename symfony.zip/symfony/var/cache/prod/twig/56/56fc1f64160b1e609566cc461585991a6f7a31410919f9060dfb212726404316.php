<?php

/* AppBundle::index.html.twig */
class __TwigTemplate_61c8ddd807f5715dec72ac6ead6c37ed96412d30ade187bc773382c958ec2e86 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'style' => array($this, 'block_style'),
            'body' => array($this, 'block_body'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"ru\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\"
          content=\"width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">
    <title>Skillup | ";
        // line 8
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <style>";
        // line 9
        $this->displayBlock('style', $context, $blocks);
        echo "</style>
    <style>
        .post {
            border: 1px solid black;
            margin: 5px;
            padding: 5px;
        }
        .created_at {
            color: gray;
        }
    </style>
</head>
<body>

";
        // line 23
        $this->displayBlock('body', $context, $blocks);
        // line 24
        echo "
";
        // line 26
        echo "    ";
        // line 27
        echo "        ";
        // line 28
        echo "        ";
        // line 29
        echo "    ";
        // line 31
        echo "
";
        // line 32
        $this->displayBlock('javascript', $context, $blocks);
        // line 33
        echo "
</body>
</html>";
    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
    }

    // line 9
    public function block_style($context, array $blocks = array())
    {
    }

    // line 23
    public function block_body($context, array $blocks = array())
    {
    }

    // line 32
    public function block_javascript($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "AppBundle::index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  92 => 32,  87 => 23,  82 => 9,  77 => 8,  71 => 33,  69 => 32,  66 => 31,  64 => 29,  62 => 28,  60 => 27,  58 => 26,  55 => 24,  53 => 23,  36 => 9,  32 => 8,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "AppBundle::index.html.twig", "/var/www/html/symfony/src/AppBundle/Resources/views/index.html.twig");
    }
}
